package hyunju.com.memo2020

import android.app.Application

class MemoApplication : Application() {
}